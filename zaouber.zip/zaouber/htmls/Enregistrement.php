<html>
<head>
	<meta charset="utf-8">
	<!--[if lt IE 9]>
<script
src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
	<title> Université Zaouber </title>
	<link rel="stylesheet" type="text/css" href="../css/css.css">
</head>
<body>
	<header>
		<div class="header-up"> 
			<img src="../images/logo-univ.png" id="logo">
		</div>
		<div class="header-down"> 
			<h1> Université Zaouber </h1>
			<h4>Science - conscience</h4>
			<nav>  
				<ul class="navig">
					<li><a href="../accueil.html">Accueil</a></li>
					<li><a href="presentation.html">Présentation</a></li>
					<li><a href="inscription.html">Inscription</a></li>
					<li><a href="etablissements.html">Etablissements</a></li>
					<li><a href="recherche.html">Recherche</a></li>
					<li><a href="contact.html">Nous contacter</a></li>

				</ul>
			</nav>
		</div>
	</header>
	<div class="container">
		<div class="left">
			<ul>
				<li><a href="#">Licence</a></li>
				<li><a href="#">Master</a></li>
				<li><a href="#">Doctorat</a></li>
			</ul>
		</div>
		<div class="body-php">
<!--DU CODE PHP -->
		<?php
			//DU CODE PHP
			$LangueFr="";
			$LangueAra="";
			$LangueAng="";
			$CheminDiplome='';
			$CheminPhoto='';
			//Verification chemin, type et taille images
			if (isset($_FILES['MaPhoto']) AND $_FILES['MaPhoto']['error']==0){
				if ($_FILES['MaPhoto']['size']<=1000000) {
					if (in_array(pathinfo($_FILES['MaPhoto']['name'])['extension'], array('jpeg','jpg','png'))) {
						move_uploaded_file($_FILES['MaPhoto']['tmp_name'] , 'uploads/photos/'.basename($_FILES['MaPhoto']['name']));
						$CheminPhoto = 'uploads/photos/'.basename($_FILES['MaPhoto']['name']);
						
						if (isset($_POST['LangueFr'])) {
							$LangueFr = 'Français';
						}
						if (isset($_POST['LangueAng'])) {
							$LangueAng = 'Anglais';
						}
						if (isset($_POST['LangueAra'])) {
							$LangueAra = 'Arabe';
						}
						if (isset($_FILES['Diplomefile']) AND $_FILES['Diplomefile']['error']==0) {
							if ($_FILES['Diplomefile']['size']<= 1000000) {
								if (in_array(pathinfo($_FILES['Diplomefile']['name'])['extension'], array('jpg','png','jpeg','pdf'))) {
									move_uploaded_file($_FILES['Diplomefile']['tmp_name'] , 'uploads/diplomes/'.basename($_FILES['Diplomefile']['name']));
									$CheminDiplome = 'uploads/diplomes/'.basename($_FILES['Diplomefile']['name']);
									
								}
							}
							
						}
						// include 'connection.php';
						$langue = $LangueFr.'-'.$LangueAng.'-'.$LangueAra;
						$sexe = htmlspecialchars($_POST['sexe']);
						$NomComplet = htmlspecialchars($_POST['NomComplet']);
						$DateNaissance = htmlspecialchars($_POST['DateNaissance']);
						$LieuNaissance = htmlspecialchars($_POST['LieuNaissance']);
						$pays = htmlspecialchars($_POST['pays']);
						$mail = htmlspecialchars($_POST['email']);
						$numero = (int)htmlspecialchars($_POST['numero']);
						$NomMere = htmlspecialchars($_POST['NomMere']);
						$NomPere = htmlspecialchars($_POST['NomPere']);
						$AdresseParent = htmlspecialchars($_POST['AdresseP']);
						$filiere = htmlspecialchars($_POST['filiere']);
						$niveau = htmlspecialchars($_POST['niveau']);
						$motivation = htmlspecialchars($_POST['motivation']);
						/////////////////////////////////////////////////////
						/////////////////////////////////////////////////////
						//Debut
						$servername = "localhost";
						$username = "root";
						$password = "";
						$db = "dtbase";
						//include 'Enregistrement.php';
						//$sql = "CREATE DATABASE ".$db;
							// Create connection 
						try {
							$conn = new PDO("mysql:host=$servername;dbname=".$db, $username, $password);
					        // set the PDO error mode to exception
							$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							//echo "Connected successfully";
						}
						catch(PDOException $e)
						{
							echo "Connection failed: " . $e->getMessage();
						}
						try {
							$champ="(nom_prenom, date_naiss, lieu_naiss, sexe, pays, tel, email, photo )";
							$valeur="('$NomComplet','$DateNaissance','$LieuNaissance','$sexe','$pays','$numero','$mail','$CheminPhoto')";
							$conn->exec("INSERT INTO etudiants".$champ." VALUES ".$valeur);
							///////////////////////////////////////////
							$champ="(nom_mere, nom_pere, adresse_parent)";
							$valeur="('$NomMere','$NomPere','$AdresseParent')";
							$conn->exec("INSERT INTO parents".$champ." VALUES ".$valeur);
							///////////////////////////////////////////
							$champ="(langue, filiere, niveau, diplome, motivation)";
							$valeur="('$langue','$filiere','$niveau','$CheminDiplome','$motivation')";
							$conn->exec("INSERT INTO donnees_academiques".$champ." VALUES ".$valeur);
							////////////////////////////////////////////
							////////////////////////////////////////////

							// AFFICHAGE DES DONNEES
							echo "<h1><br/>Données enregistrées avec Succès!<br/></h1>";
							echo "<img src='".$CheminPhoto."' width='100px' height='100px' /> <br/>";
							echo "<h3><u> Etudiant </u> : ".$NomComplet."<h3/>";
							echo "<h3><u> Naissance </u> : ".$DateNaissance." à ".$LieuNaissance."</h3>" ;
							echo "<h3><u> Filière </u> : ".$filiere."</h3>" ;
							echo "<h3><u> Niveau </u> : ".$niveau."</h3>" ;
							echo "<h3><u> Contact </u> : ".$numero."</h3>" ;

						} catch (Exception $e) {
							echo "Erreur : ", $e->getMessage(), "\n";
						}
						$conn=NULL;

					}	
				}
					
			}

		?>
		</div>

		<div class="right"> 
			<div class="right-l"><h3>Mot du Recteur</h3></div>
			<div class="right-c"><img src="../images/recteur.jpg" id="recteur"></div>
			<div class="right-r">Uni-zaouber</div>
		</div>
		
	</div>

<footer>
	<p> &nbsp &nbsp © 2009-2020 | &nbsp Univ-zaouber &nbsp</p>
</footer>
</body>
</html>		

		

